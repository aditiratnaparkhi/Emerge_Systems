SELECT *
FROM group_table
WHERE t_stamp BETWEEN :startDate AND :endDate