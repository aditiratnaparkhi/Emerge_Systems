SELECT *
FROM group_table
WHERE t_stamp BETWEEN :StartDate  AND  :EndDate